CONTENTS OF THIS FILE
---------------------
   
 * Introduction
 * Fork
 * Select
 * UDP

INTRODUCTION
------------

These listing are the work produced by 4th years students Tommaso Marenzi, Georgina Sheehan and Noel WIlliams for Padraig Moran, lecturer of the Networked Games module of the Computer Games Design and Development course at LIT.
The group assignment requested the development of three pairs of sockets applications (client and server) that exploited the principles of forking, selecting and UDP.
The final source code is available in the folder "src" which contains three folders with all the files necessary to build and run each pair of applications.


FORK
----

The code included in the "src/fork" folder has been written by Georgina Sheean.
Once in that folder use the following to test the applications:

* Compile and running the Server
  
  - For compiling the Server use the command:
    gcc -o hangserver_fork hangserver_fork.c Hangman.c Practical.h

  - Once compiled run the server Server with the command:
    ./hangserver_fork

* Compiling and running the Client
  
  - For compiling the Client use the command:
    gcc -o hangclient hangclient.c

  - Once compiled run the Client with the command:
    ./hangclient



SELECT
------

The code included in the "src/select" folder has been written by Noel Williams.
Unfortunately the application doesn't run, but code can be still examined by looking at the different source files.



UDP
---

The code included in the "src/udp" folder has been written by Tommaso Marenzi.
Once in that folder use the following to test the applications:

* Compile and running the Server
  
  - Ensure that the folder "common" is included in the "udp" folder 
    and that both "GameList.h" and "GameList.c" files are present.

  - For compiling the Server use the command:
    gcc -o hServUDP hangserver_udp.c common/GameList.c

  - Once compiled run the server Server with the command:
    ./hServUDP

* Compiling and running the Client
  
  - For compiling the Client use the command:
    gcc -o hCliUDP hangclient_udp.c

  - Once compiled run the Client with the command:
    ./hCliUDP


