#ifndef HANGMAN_H
#define HANGMAN_H

void play_hangman(int in, int out);

#endif //HANGMAN_H