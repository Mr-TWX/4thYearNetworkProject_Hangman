#ifndef PRACTICAL_H_
#define PRACTICAL_H_

 
 # define MAXIMUM_LIVES 12;
 # define NUM_OF_WORDS (sizeof (word) / sizeof (word [0]))
 # define MAXLEN 80 /* Maximum size in the world of Any string */
 # define HANGMAN_TCP_PORT 1066


#endif // PRACTICAL_H_
